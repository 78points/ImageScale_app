// Load native UI library
var gui = require('nw.gui');

var win = gui.Window.get();

// Create menu
 var menu = new gui.Menu({ type: 'menubar' });

// Create sub-menu
var menuItems = new gui.Menu();

var menuHelp = new gui.Menu();



//==== menu menuItems =====
menuItems.append(new gui.MenuItem({
	label: 'Dashboard',
		click: function() {
 		   console.log("home clicked");
 		   window.location.href = "index.html";
		  }
	 }));


menuItems.append(new gui.MenuItem({
	label: 'Quit ImageScale',
		click: function() {
 		   win.close(true);
		  },
		  key: "q",
		  modifiers: "ctrl-alt",
	 }));
//==== end menu menuItems =====



// ====== menu menuHelp===========

/*
menuHelp.append(new gui.MenuItem({
	label: 'Debuger',
		click: function() {
 		   win.showDevTools();
		  },
		  key: "d",
		  modifiers: "ctrl-alt",
	 }));
*/

menuHelp.append(new gui.MenuItem({
	label: 'About',
		click: function() {
 		 gui.Shell.openExternal( 'http://78points.com/ImageScale/');
		  }
	 }));


// ====== end menu menuHelp ===========




/* mac only */
// create MacBuiltin
menu.createMacBuiltin('ImageScale',{
    hideEdit: true, //true to hide edit tab
    hideWindow: true //true to hide window tab
});



// Append MenuItem as a Submenu
menu.append(
    new gui.MenuItem({
        label: 'ImageScale',
        submenu: menuItems
    })
);




menu.append(
    new gui.MenuItem({
        label: 'Help',
        submenu: menuHelp
    })
);



// Append Menu to Window
gui.Window.get().menu = menu;
