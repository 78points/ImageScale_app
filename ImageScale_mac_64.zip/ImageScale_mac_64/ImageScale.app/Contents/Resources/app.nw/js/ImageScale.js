$( document ).ready(function() {



//var lwip = require('lwip');
var mime = require('mime');
var walk    = require('walk');
var files   = [];
var fs = require("fs");

var Jimp = require("jimp");

var savedImages = 0;
var scanedImages = 0;
var greyscale = false;

$( "#settingsForm" ).submit(function( event ) {
  event.preventDefault();

  var orginalImagesDir = $('#chooser1').val();
  var smallImagesDir = $('#chooser2').val();

  var imageWidth = parseInt( $('#imageWidth').val() );
  var imageHeight = $('#imageHeight').val();
  if(imageHeight === 'auto'){
    imageHeight = Jimp.AUTO;
  }else{
    imageHeight = parseInt( $('#imageHeight').val() );
  }

  var imageQuality = parseInt( $('#imageQuality').val() );
  var greyscale = $('#greyscale').is(':checked');
  var sepia = $('#sepia').is(':checked');
  var imageBlur = parseInt( $('#imageBlur').val() );
  var imagePrefix = $('#imagePrefix').val();


  $('#output').prepend('scaning directory: ' + orginalImagesDir  + '\n');
  $('#spiner').css('visibility', 'visible');


 if($('#messModal').modal('show')){
   $('#messModal').modal({ keyboard: false});
  // scanDirectory();
   setTimeout(function() { scanDirectory(); }, 5000);
 }


 function scanDirectory(){
   // Walker options
   var walker  = walk.walk( orginalImagesDir, { followLinks: false });
   walker.on('file', function(root, stat, next) {
   files.push( stat.name );
   imgMine = mime.lookup( orginalImagesDir + stat.name );
   if( imgMine === 'image/jpeg' || imgMine === 'image/png' || imgMine === 'image/jpg'){
   //  console.log(stat.name);
   $('#output').prepend('found: ' + stat.name  + '\n');
   resizeImage( stat.name );
   scanedImages = ++scanedImages;
   }
   next();
   });

   walker.on('end', function() {
      console.log('All files scaned.')
      $('#output').prepend('All files scaned. Working with images now... ' + '\n');
    });
 } //scanDirectory





  function resizeImage( image ){

  var orginalImage = image;
  var newImage = imagePrefix + orginalImage;

    Jimp.read( orginalImagesDir + '/'+ orginalImage , function (err, lenna) {
        if (err) throw err;
        lenna.resize( imageWidth , imageHeight );
    //  lenna.contain( imageWidth , imageHeight  )
        lenna.quality(imageQuality);
        if(greyscale === true){
          lenna.greyscale();
        }
        if(sepia === true){
          lenna.sepia();
        }
        if(imageBlur > 0){
          lenna.blur( imageBlur );
            $('#output').prepend('Aplaying image blur \n');
        }

    if(lenna.write( smallImagesDir + '/'+ newImage )){
      console.log(newImage + ' saved');
      $('#output').prepend(newImage + ' saved \n');
      savedImages = ++savedImages;
    }

    if (scanedImages === savedImages){
        $('#spiner').css('visibility', 'hidden');
      //  alert('Job done!!!');
        $('#messModal').modal('hide');
    }


    });


  }





}); // submit


}); //document ready
